---
title: KubeStash Elasticsearch Addon
menu:
  docs_{{ .version }}:
    identifier: kubestash-elasticsearch
    name: Elasticsearch
    parent: kubestash-addons
    weight: 40
menu_name: docs_{{ .version }}
---